import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
import { getStorage } from "firebase/storage"; 


const firebaseConfig = {
  apiKey: "AIz",
  authDomain: "de",
  projectId: "delivery-dz",
  storageBucket: "del",
  messagingSenderId: "2902",
  appId: "1:290283262",
};

export const app = initializeApp(firebaseConfig);

//init database
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app); // ✅ This line must work