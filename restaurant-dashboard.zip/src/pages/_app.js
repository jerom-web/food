import "@/styles/globals.css";
import { ThemeProvider } from "@/context/ThemeContext";
import { LanguageProvider } from "@/context/LanguageContext";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { Toaster } from "react-hot-toast";
import { useRouter } from "next/router";
import { useEffect } from "react";

// 🧩 Toggle buttons
import ThemeToggle from "@/components/ThemeToggle";
import LanguageToggle from "@/components/LanguageToggle";

// 🔒 Create an AuthGate wrapper to protect verified routes
const AuthGate = ({ children }) => {
  const { user, userVerified, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    const publicRoutes = ["/login", "/register" ];
    const isPublic = publicRoutes.includes(router.pathname);

    {/* 🔐 Redirect unverified users to /verify */}
    {/*if (!loading && user && !userVerified && !isPublic) {
      router.push("/verify");
    }*/}
  }, [user, userVerified, loading, router]);

  return children;
};

export default function App({ Component, pageProps }) {
  return (
    <AuthProvider>
      <LanguageProvider>
        <ThemeProvider>
          <Toaster position="top-center" />
          
          {/* 🔼 Header with theme/language toggles */}
          <div className="flex justify-end items-center gap-2 px-4 py-2 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700">
            <LanguageToggle />
            <ThemeToggle />
          </div>

          {/* 🔐 Verified routes */}
          <AuthGate>
            <Component {...pageProps} />
          </AuthGate>
        </ThemeProvider>
      </LanguageProvider>
    </AuthProvider>
  );
}
