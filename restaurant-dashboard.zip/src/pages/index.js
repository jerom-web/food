import { useAuth } from "@/context/AuthContext";
import { useRouter } from "next/router";
import { useEffect } from "react";
import Sidebar from "@/components/Sidebar";

export default function Home() {
  const { user, loading } = useAuth();
  const router = useRouter();

  // 🔐 Redirect unauthenticated users to /login
  useEffect(() => {
    if (!loading && !user) {
      router.push("/login");
    }
  }, [user, loading, router]);

  // ⏳ Show loading state
  if (loading) return <p>Loading...</p>;

  // ⛔ Block rendering if user is not authenticated
  if (!user) return null;

  // ✅ Render the Sidebar (main content)
  return <Sidebar />;
}
