import Login from "@/components/Auth/Login";

export default function LoginPage() {
  return <Login />;
}
