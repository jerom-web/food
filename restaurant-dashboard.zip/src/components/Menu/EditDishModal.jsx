import { useState } from "react";
import { db, storage } from "@/firebase/firebase";
import { doc, updateDoc, serverTimestamp } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import imageCompression from "browser-image-compression";

const EditDishModal = ({ editingDish, setIsEditing, setIsUpdated }) => {
  const [name, setName] = useState(editingDish.name || "");
  const [price, setPrice] = useState(editingDish.price || "");
  const [description, setDescription] = useState(editingDish.description || "");
  const [imageFile, setImageFile] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleUpdate = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      let imageUrl = editingDish.image;

      if (imageFile) {
        const compressedFile = await imageCompression(imageFile, {
          maxSizeMB: 1,
          maxWidthOrHeight: 1280,
          useWebWorker: true,
        });

        const imageRef = ref(storage, `imagesfood/${Date.now()}-${compressedFile.name}`);
        await uploadBytes(imageRef, compressedFile);
        imageUrl = await getDownloadURL(imageRef);
      }

      const dishRef = doc(db, "dishes", editingDish.id);
      await updateDoc(dishRef, {
        name,
        price,
        description,
        image: imageUrl,
        updatedAt: serverTimestamp(),
      });

      setIsUpdated(true);         // ✅ trigger parent to reload dishes
      setIsEditing(false);        // ✅ close modal
    } catch (error) {
      console.error("Update failed:", error);
      alert("Update failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-10 overflow-y-auto bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white dark:bg-gray-900 w-full max-w-lg p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold text-center mb-4 text-gray-800 dark:text-white">Edit Dish</h2>
        <form onSubmit={handleUpdate}>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Dish Name"
            className="w-full mb-4 p-2 border rounded dark:bg-gray-800 dark:text-white"
            required
          />
          <input
            type="text"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            placeholder="Price"
            className="w-full mb-4 p-2 border rounded dark:bg-gray-800 dark:text-white"
            required
          />
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Description"
            className="w-full mb-4 p-2 border rounded dark:bg-gray-800 dark:text-white"
          />
          <input
            type="file"
            accept="image/*"
            onChange={(e) => setImageFile(e.target.files[0])}
            className="w-full mb-4"
          />
          <div className="flex justify-between">
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
            >
              {loading ? "Updating..." : "Update Dish"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditDishModal;
