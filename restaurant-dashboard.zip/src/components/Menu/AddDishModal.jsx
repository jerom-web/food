import { useState, useEffect } from "react";
import { db, storage } from "../../firebase/firebase";
import {
  collection,
  addDoc,
  getDocs,
  serverTimestamp,
} from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import imageCompression from "browser-image-compression";
import { useAuth } from "@/context/AuthContext";
import Image from "next/image";

const AlertBox = ({ message, type = "error", onClose }) => {
  const colors = {
    error: "bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 border-red-500",
    success: "bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 border-green-500",
  };

  return (
    <div className={`fixed top-4 left-1/2 transform -translate-x-1/2 z-50 px-6 py-3 rounded-xl border-l-4 border-b-4 shadow-md ${colors[type]}`}>
      <div className="flex justify-between items-center gap-3">
        <span className="font-semibold">{message}</span>
        <button onClick={onClose} className="text-xl font-bold">&times;</button>
      </div>
    </div>
  );
};

const AddDishModal = ({ setIsActive, restaurantId }) => {
  const { user } = useAuth();
  const [name, setName] = useState("");
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const [alert, setAlert] = useState({ show: false, message: "", type: "error" });
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("");

  const showAlert = (message, type = "error", duration = 3000) => {
    setAlert({ show: true, message, type });
    setTimeout(() => setAlert(prev => ({ ...prev, show: false })), duration);
  };

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const snap = await getDocs(collection(db, "categories"));
        const catList = snap.docs.map(doc => doc.data());
        setCategories(catList);
      } catch (err) {
        console.error("Error loading categories", err);
      }
    };
    fetchCategories();
  }, []);

  const isValidImage = (file) => {
    const validTypes = ["image/jpeg", "image/png", "image/webp"];
    const isValidType = validTypes.includes(file.type);
    if (!isValidType) {
      showAlert(`Invalid file type (${file.type}). Only JPG/PNG/WEBP allowed.`);
      return false;
    }
    return true;
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file && isValidImage(file)) {
      setImageFile(file);
      setImagePreview(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!restaurantId || !user?.uid) {
      showAlert("Missing user or restaurant ID.");
      return;
    }

    if (!imageFile) {
      showAlert("Please select an image.");
      return;
    }

    if (!selectedCategory) {
      showAlert("Please select a category.");
      return;
    }

    try {
      const compressedFile = await imageCompression(imageFile, {
        maxSizeMB: 2,
        maxWidthOrHeight: 1280,
        useWebWorker: true,
      });

      const timestamp = Date.now();
      const safeName = compressedFile.name.replace(/[^a-z0-9.\-_]/gi, "_");
      const storageRef = ref(storage, `imagesfood/${timestamp}-${safeName}`);
      await uploadBytes(storageRef, compressedFile);
      const imageUrl = await getDownloadURL(storageRef);

      await addDoc(collection(db, "dishes"), {
        name,
        price,
        description,
        image: imageUrl,
        restaurantId,
        uid: user.uid,
        category: selectedCategory,
        createdAt: serverTimestamp(),
      });

      showAlert("Dish added successfully!", "success");
      setTimeout(() => setIsActive(false), 2000);
    } catch (err) {
      console.error("Upload failed:", err);
      showAlert("Failed to upload dish. Try again.");
    }
  };

  return (
    <div className="fixed inset-0 z-10 overflow-y-auto">
      {alert.show && (
        <AlertBox
          message={alert.message}
          type={alert.type}
          onClose={() => setAlert(prev => ({ ...prev, show: false }))}
        />
      )}

      <div className="fixed inset-0 w-full h-full bg-black opacity-60" onClick={() => setIsActive(false)}></div>
      <div className="flex items-center min-h-screen px-4 py-8">
        <div className="relative w-full max-w-2xl p-6 mx-auto bg-white dark:bg-gray-900 rounded-xl shadow-lg text-gray-800 dark:text-white">
          <div className="flex justify-end">
            <button className="p-2 text-gray-500 dark:text-gray-300 rounded-lg hover:bg-red-100 dark:hover:bg-red-800" onClick={() => setIsActive(false)}>
              <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5 mx-auto" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          </div>

          <div className="max-w-sm mx-auto py-3 space-y-3 text-center">
            <h4 className="text-2xl font-bold">Add Dish</h4>
            <form onSubmit={handleSubmit}>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Name"
                className="w-full mb-4 p-2 border rounded bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
              />
              <input
                type="text"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="Price"
                className="w-full mb-4 p-2 border rounded bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
              />
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={handleImageChange}
                className="w-full mb-4"
              />
              {imagePreview && (
                <Image
                  src={imagePreview}
                  alt="Preview"
                  width={400}
                  height={192}
                  className="w-full h-48 object-cover rounded mb-4"
                />
              )}
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Description"
                className="w-full mb-4 p-2 border rounded bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
              />

              {/* Category Dropdown */}
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full mb-4 p-2 border rounded bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
              >
                <option value="">Select Category</option>
                {categories.map((cat, i) => (
                  <option key={i} value={cat.name}>{cat.name}</option>
                ))}
              </select>

              <button className="w-full bg-green-100 dark:bg-green-700 border-l-4 border-b-4 border-green-500 text-gray-700 dark:text-white font-semibold py-2 rounded-xl hover:bg-green-200 dark:hover:bg-green-600 transition">
                Add
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddDishModal;
