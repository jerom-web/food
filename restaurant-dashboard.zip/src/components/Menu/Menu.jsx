import { db } from "@/firebase/firebase";
import { collection, getDocs, query, where } from "firebase/firestore";
import { useEffect, useState } from "react";
import AddDishModal from "./AddDishModal";
import EditDishModal from "./EditDishModal";
import MenuItem from "./MenuItem";
import { useAuth } from "@/context/AuthContext";

const Menu = () => {
  const { user } = useAuth();
  const [restaurantId, setRestaurantId] = useState(null);
  const [dishes, setDishes] = useState([]);
  const [isActive, setIsActive] = useState(false);
  const [isRemoved, setIsRemoved] = useState(false);
  const [isUpdated, setIsUpdated] = useState(false);
  const [editingDish, setEditingDish] = useState(null);
  const [isEditing, setIsEditing] = useState(false);

  // ✅ Get restaurantId from Firestore by matching logged-in user UID
  useEffect(() => {
    const fetchRestaurantId = async () => {
      try {
        if (!user?.uid) return;
        const q = query(collection(db, "restaurants"), where("uid", "==", user.uid));
        const snapshot = await getDocs(q);
        if (!snapshot.empty) {
          setRestaurantId(snapshot.docs[0].id);
        } else {
          console.error("No restaurant found for this user.");
        }
      } catch (error) {
        console.error("Failed to fetch restaurant ID:", error);
      }
    };

    fetchRestaurantId();
  }, [user]);

  // ✅ Get dishes for current restaurantId
  useEffect(() => {
    const fetchDishes = async () => {
      if (!restaurantId) return;
      try {
        const q = query(collection(db, "dishes"), where("restaurantId", "==", restaurantId));
        const snapshot = await getDocs(q);
        const items = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setDishes(items);
      } catch (err) {
        console.error("Failed to fetch dishes:", err);
      }
    };

    fetchDishes();
    setIsRemoved(false);
    setIsUpdated(false);
  }, [restaurantId, isActive, isRemoved, isUpdated]);

  return (
    <div className="max-w-4xl pt-8 px-4 md:px-8">
      {isActive && (
        <AddDishModal setIsActive={setIsActive} restaurantId={restaurantId} />
      )}
      {isEditing && (
        <EditDishModal
          editingDish={editingDish}
          setIsEditing={setIsEditing}
          setIsUpdated={setIsUpdated}
        />
      )}
      <MenuItem
        setIsActive={() => setIsActive(true)}
        dishes={dishes}
        setIsRemoved={setIsRemoved}
        setEditingDish={setEditingDish}
        setIsEditing={setIsEditing}
      />
    </div>
  );
};

export default Menu;
