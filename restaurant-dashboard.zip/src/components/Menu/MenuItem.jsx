import { db } from "../../firebase/firebase";
import { deleteDoc, doc } from "firebase/firestore"; // ✅ ADD THIS
import Image from 'next/image';

const MenuItem = ({ setIsActive, dishes, setIsRemoved, setEditingDish, setIsEditing }) => {
  const handleRemove = async (id) => {
    await deleteDoc(doc(db, "dishes", id));
    setIsRemoved(true);
  };

  return (
    <>
      <div className="items-start justify-between sm:flex">
        <h4 className="text-3xl font-bold">Menu</h4>
        <button
          onClick={setIsActive}
          className="inline-flex items-center gap-1 py-2 px-3 mt-2 font-medium text-sm text-gray-700 bg-green-100 border-l-4 border-b-4 border-green-500 hover:bg-green-100 active:bg-green-400 duration-150 rounded-xl sm:mt-0"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v12m6-6H6" />
          </svg>
          Add Dish
        </button>
      </div>
      <ul className="mt-12 divide-y">
        {dishes.map((item) => (
          <li key={item.id} className="py-5 flex items-start justify-between">
            <div className="flex gap-3">
              <Image src={item.image} className="w-20 h-20 rounded-xl object-cover" alt={item.name} />
              <div>
                <span className="block text-lg font-bold">{item.name}</span>
                <span className="block text-lg">DZ. {item.price}</span>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  setEditingDish(item);
                  setIsEditing(true);
                }}
                className="p-2 text-sm text-blue-600 bg-blue-100 border-l-4 border-b-4 border-blue-400 rounded-xl hover:bg-blue-200"
              >
                Edit
              </button>
              <button
                onClick={() => handleRemove(item.id)}
                className="p-2 text-sm text-red-600 bg-red-100 border-l-4 border-b-4 border-red-400 rounded-xl hover:bg-red-200"
              >
                Remove
              </button>
            </div>
          </li>
        ))}
      </ul>
    </>
  );
};

export default MenuItem;
