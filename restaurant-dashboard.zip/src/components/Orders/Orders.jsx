import { useEffect, useState } from "react";
import { db } from "../../firebase/firebase";
import {
  collection,
  getDocs,
  query,
  where,
  orderBy,
} from "firebase/firestore";
import { useAuth } from "@/context/AuthContext";
import OrderModal from "./OrderModal";

const Orders = () => {
  const { user } = useAuth();
  const [orders, setOrders] = useState([]);
  const [restaurantId, setRestaurantId] = useState(null);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Fetch restaurant ID for the logged-in user
  useEffect(() => {
    const fetchRestaurantId = async () => {
      try {
        const restaurantRef = collection(db, "restaurants");
        const q = query(restaurantRef, where("uid", "==", user.uid));
        const snapshot = await getDocs(q);

        if (!snapshot.empty) {
          const doc = snapshot.docs[0];
          setRestaurantId(doc.id);
        } else {
          console.error("No restaurant found for this user.");
        }
      } catch (err) {
        console.error("Failed to fetch restaurant ID:", err);
      }
    };

    if (user?.uid) fetchRestaurantId();
  }, [user]);

  // Fetch pending orders for the restaurant
  useEffect(() => {
    const fetchOrders = async () => {
      try {
        if (!restaurantId) return;

        const ordersRef = collection(db, "orders");
        const q = query(
          ordersRef,
          where("restaurantId", "==", restaurantId),
          where("status", "==", "PENDING"),
          orderBy("createdAt", "desc")
        );

        const snapshot = await getDocs(q);
        const data = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setOrders(data);
      } catch (err) {
        console.error("Failed to fetch orders:", err);
      }
    };

    fetchOrders();
  }, [restaurantId]);

  return (
    <div className="p-4 md:p-6 bg-gray-50 dark:bg-gray-900 min-h-screen text-gray-900 dark:text-white">
      <h1 className="text-2xl font-bold mb-6">Pending Orders</h1>

      {orders.length === 0 ? (
        <div className="text-center text-gray-500 dark:text-gray-400">
          No pending orders.
        </div>
      ) : (
        <ul className="space-y-4">
          {orders.map((order) => (
            <li
              key={order.id}
              className="p-4 rounded-xl shadow-md bg-white dark:bg-gray-800 border dark:border-gray-700 cursor-pointer hover:shadow-lg"
              onClick={() => {
                setSelectedOrder(order);
                setIsModalOpen(true);
              }}
            >
              <p className="mb-2"><strong>Customer:</strong> {`${order.userFirstName ?? ""} ${order.userLastName ?? ""}`.trim() || "N/A"}</p>
              <p className="mb-2"><strong>Total:</strong> {order.total || 0} DA</p>
              <p className="mb-2"><strong>Status:</strong> {order.status}</p>
            </li>
          ))}
        </ul>
      )}

      {isModalOpen && selectedOrder && (
        <OrderModal selectedOrder={selectedOrder} setIsActive={setIsModalOpen} />
      )}
    </div>
  );
};

export default Orders;
