import { useState, useEffect, useContext } from "react";
import { navigation } from "../data/navigation";
import { navsFooter } from "../data/navsFooter";
import Orders from "./Orders/Orders";
import OrderHistory from "./OrderHistory/OrderHistory";
import Menu from "./Menu/Menu";
import Settings from "./Settings/Settings";
import { db, auth } from "../firebase/firebase";
import { doc, getDoc } from "firebase/firestore";
import ThemeToggle from "./ThemeToggle";
import LanguageToggle from "./LanguageToggle";
import { LanguageContext } from "../context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import Image from 'next/image';

const Sidebar = () => {
  const [active, setActive] = useState(0);
  const [restaurant, setRestaurant] = useState({});
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { lang } = useContext(LanguageContext);

  const t = {
    dashboard: { en: "Dashboard", fr: "Tableau de bord", ar: "لوحة التحكم" },
  };

  useEffect(() => {
    const getRestaurant = async () => {
      const user = auth.currentUser;
      if (!user) return;

      const resRef = doc(db, "restaurants", user.uid);
      const docSnapshot = await getDoc(resRef);
      if (docSnapshot.exists()) {
        setRestaurant({ ...docSnapshot.data(), id: docSnapshot.id });
      }
    };

    getRestaurant();
  }, []);

  const handleMenuClick = (index) => {
    setActive(index);
    if (window.innerWidth < 768) {
      setSidebarOpen(false);
    }
  };

  const handleLogout = async () => {
    await auth.signOut();
    window.location.href = "/login";
  };

  return (
    <div className="flex h-screen">
      {/* Toggle button for mobile */}
      <button
        onClick={() => setSidebarOpen(!sidebarOpen)}
        className="absolute top-4 left-4 z-50 p-2 rounded-md bg-green-600 text-white md:hidden"
      >
        ☰
      </button>

      {/* Sidebar */}
      <div
        className={`fixed z-40 top-0 left-0 h-full bg-white dark:bg-gray-900 w-64 transform transition-transform duration-300 ease-in-out ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        } md:translate-x-0 md:relative md:flex md:flex-col md:w-3/12 border-r dark:border-gray-800`}
      >
        <div className="flex flex-col h-full space-y-6 px-4 pt-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <p className="font-bold text-2xl">{t.dashboard[lang]}</p>
            <div className="flex items-center gap-2">
              
            </div>
          </div>

          {/* Navigation */}
          <ul className="text-sm font-medium flex-1 overflow-auto">
            {navigation.map((item, index) => (
              <li key={index} onClick={() => handleMenuClick(index)}>
                <div
                  className={`my-3 cursor-pointer flex items-center gap-x-2 text-gray-700 dark:text-white text-base p-2 rounded-xl hover:bg-green-100 dark:hover:bg-green-800 active:bg-green-400 duration-150 ${
                    active === index
                      ? "bg-green-100 dark:bg-green-800 border-l-4 border-b-4 border-green-500"
                      : ""
                  }`}
                >
                  <div className="text-gray-500 dark:text-gray-300">
                    {item.icon}
                  </div>
                  {item.name}
                </div>
              </li>
            ))}
          </ul>

          {/* Footer */}
          <div className="pb-4">
            <ul className="text-sm font-medium">
              {navsFooter.map((item, index) => (
                <li key={index}>
                  <button
                    onClick={handleLogout}
                    className="w-full text-left flex items-center gap-x-2 text-gray-700 dark:text-white text-base p-2 rounded-xl hover:bg-green-100 dark:hover:bg-green-800 duration-150"
                  >
                    <div className="text-gray-500 dark:text-gray-300">
                      {item.icon}
                    </div>
                    {item.name}
                  </button>
                </li>
              ))}
            </ul>

            {/* Restaurant Info */}
            <div className="py-4 border-t border-gray-200 dark:border-gray-700">
              <div className="flex items-center gap-x-4">
                <Image
                  src={restaurant.image}
                  className="w-12 h-12 object-cover rounded-full"
                  alt="Restaurant"
                />
                <div>
                  <p className="text-base font-bold text-gray-700 dark:text-white">
                    {restaurant.name}
                  </p>
                  <p className="text-sm text-gray-500 dark:text-gray-300">
                    {restaurant.city}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-auto w-full md:w-9/12 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-white p-4 overflow-auto">
        {active === 0 && <Orders />}
        {active === 1 && <Menu />}
        {active === 2 && <OrderHistory />}
        {active === 3 && <Settings />}
      </div>
    </div>
  );
};

export default Sidebar;
