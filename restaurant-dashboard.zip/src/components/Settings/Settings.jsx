import { useState, useEffect } from "react";
import { db } from "../../firebase/firebase";
import {
  doc,
  updateDoc,
  collection,
  query,
  where,
  getDocs,
} from "firebase/firestore";
import {
  getStorage,
  ref,
  uploadBytes,
  getDownloadURL,
} from "firebase/storage";
import imageCompression from "browser-image-compression";
import { v4 as uuidv4 } from "uuid";
import { useAuth } from "@/context/AuthContext";
import toast from "react-hot-toast";
import Image from "next/image";

const storage = getStorage();

const Settings = () => {
  const [restaurantData, setRestaurantData] = useState({
    name: "",
    image: "",
    address: "",
    genre: "",
  });
  const [uploading, setUploading] = useState(false);
  const { user } = useAuth();
  const [restaurantId, setRestaurantId] = useState(null);
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    const fetchRestaurant = async () => {
      if (!user) return;
      try {
        const q = query(
          collection(db, "restaurants"),
          where("uid", "==", user.uid)
        );
        const querySnapshot = await getDocs(q);
        if (!querySnapshot.empty) {
          const docSnap = querySnapshot.docs[0];
          setRestaurantData(docSnap.data());
          setRestaurantId(docSnap.id);
        }
      } catch (error) {
        console.error("Failed to fetch restaurant:", error);
        toast.error("Error loading restaurant data");
      }
    };

    const fetchCategories = async () => {
      try {
        const catSnapshot = await getDocs(collection(db, "categories"));
        const catList = catSnapshot.docs.map((doc) => doc.data()); // { name, icon }
        setCategories(catList);
      } catch (err) {
        console.error("Failed to fetch categories", err);
        toast.error("Failed to load categories");
      }
    };

    fetchRestaurant();
    fetchCategories();
  }, [user]);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setRestaurantData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const options = {
      maxSizeMB: 0.5,
      maxWidthOrHeight: 1024,
      useWebWorker: true,
    };

    setUploading(true);

    try {
      const compressed = await imageCompression(file, options);
      const imageRef = ref(
        storage,
        `restaurantImages/${uuidv4()}_${file.name}`
      );
      await uploadBytes(imageRef, compressed);
      const url = await getDownloadURL(imageRef);
      setRestaurantData((prev) => ({ ...prev, image: url }));
      toast.success("Image uploaded successfully");
    } catch (err) {
      console.error("Image upload error:", err);
      toast.error("Image upload failed.");
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!restaurantId) return toast.error("Restaurant not found");

    const dataToUpdate = {};
    for (const [key, value] of Object.entries(restaurantData)) {
      if (typeof value === "string") {
        const trimmed = value.trim();
        if (trimmed !== "") {
          dataToUpdate[key] = trimmed;
        }
      } else if (value !== null && value !== undefined) {
        dataToUpdate[key] = value;
      }
    }

    if (Object.keys(dataToUpdate).length === 0) {
      return toast.error("Please fill at least one field");
    }

    try {
      const resRef = doc(db, "restaurants", restaurantId);
      await updateDoc(resRef, dataToUpdate);
      toast.success("Restaurant details updated!");
    } catch (error) {
      console.error("Error updating restaurant:", error);
      toast.error("Failed to update restaurant.");
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="max-w-2xl pt-8 px-4 md:px-8">
        <h4 className="text-gray-800 text-3xl font-bold mb-8 dark:text-white">
          Edit restaurant details
        </h4>

        <div className="grid grid-cols-2 gap-y-12">
          {/* Name */}
          <div className="mx-auto max-w-md rounded-3xl bg-white dark:bg-gray-800 shadow-md">
            <div className="p-6">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                Name
              </h3>
              <input
                type="text"
                name="name"
                value={restaurantData.name}
                onChange={handleInputChange}
                className="w-full border border-gray-300 dark:border-gray-600 rounded-2xl py-2 px-3 mt-4 focus:outline-none focus:ring focus:ring-green-200 focus:border-green-300 bg-white dark:bg-gray-700 text-gray-800 dark:text-white placeholder-gray-400 dark:placeholder-gray-400"
                placeholder="Enter restaurant name"
              />
            </div>
          </div>

          {/* Image Upload */}
          <div className="mx-auto max-w-md rounded-3xl bg-white dark:bg-gray-800 shadow-md">
            <div className="p-6">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                Image
              </h3>
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="w-full py-2 px-3 mt-4 text-gray-700 dark:text-white"
              />
              {uploading && (
                <p className="text-sm text-gray-500 mt-2">Uploading image...</p>
              )}
              {restaurantData.image && (
                <Image
                  src={restaurantData.image}
                  alt="Preview"
                  width={400}
                  height={192}
                  className="mt-4 w-full h-48 object-cover rounded-xl"
                />
              )}
            </div>
          </div>

          {/* Address */}
          <div className="mx-auto max-w-md rounded-3xl bg-white dark:bg-gray-800 shadow-md">
            <div className="p-6">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                Address
              </h3>
              <input
                type="text"
                name="address"
                value={restaurantData.address}
                onChange={handleInputChange}
                className="w-full border border-gray-300 dark:border-gray-600 rounded-2xl py-2 px-3 mt-4 focus:outline-none focus:ring focus:ring-green-200 focus:border-green-300 bg-white dark:bg-gray-700 text-gray-800 dark:text-white placeholder-gray-400 dark:placeholder-gray-400"
                placeholder="Enter restaurant address"
              />
            </div>
          </div>

          {/* Genre - Custom with Icons */}
          <div className="mx-auto max-w-md rounded-3xl bg-white dark:bg-gray-800 shadow-md">
            <div className="p-6">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                Category
              </h3>

              <div className="mt-4 space-y-2">
                {categories.map((cat, index) => (
                  <div
                    key={index}
                    onClick={() =>
                      setRestaurantData((prev) => ({
                        ...prev,
                        genre: cat.name,
                      }))
                    }
                    className={`flex items-center gap-4 cursor-pointer border px-4 py-2 rounded-xl 
                      ${
                        restaurantData.genre === cat.name
                          ? "bg-green-100 dark:bg-green-700 border-green-500"
                          : "bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600"
                      }`}
                  >
                    <img
                      src={cat.icon}
                      alt={cat.name}
                      className="w-8 h-8 rounded-full object-cover"
                    />
                    <span className="text-gray-800 dark:text-white font-medium">
                      {cat.name}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Submit */}
          <div className="col-span-2">
            <button
              type="submit"
              className="w-full my-3 cursor-pointer items-center gap-x-2 font-semibold text-base p-3 rounded-xl 
                text-gray-800 dark:text-white 
                bg-green-100 dark:bg-green-700 
                hover:bg-green-200 dark:hover:bg-green-600 
                active:bg-green-300 border-l-4 border-b-4 border-green-500 transition"
            >
              Update Details
            </button>
          </div>
        </div>
      </div>
    </form>
  );
};

export default Settings;
