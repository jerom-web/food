import { useContext } from "react";
import { LanguageContext } from "../context/LanguageContext";

const LanguageToggle = () => {
  const { lang, changeLanguage } = useContext(LanguageContext);

  return (
    <div className="flex items-center gap-1 bg-gray-100 dark:bg-gray-700 rounded-full p-1">
      {["en", "fr", "ar"].map((code) => (
        <button
          key={code}
          onClick={() => changeLanguage(code)}
          className={`px-3 py-1 text-xs font-semibold rounded-full transition-all duration-200
            ${lang === code 
              ? "bg-green-500 text-white" 
              : "text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600"}`}
        >
          {code.toUpperCase()}
        </button>
      ))}
    </div>
  );
};

export default LanguageToggle;



