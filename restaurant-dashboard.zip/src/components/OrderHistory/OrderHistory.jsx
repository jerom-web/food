import { db } from "../../firebase/firebase";
import {
  collection,
  getDocs,
  query,
  where,
  orderBy,
} from "firebase/firestore";
import { useEffect, useState } from "react";
import { useAuth } from "@/context/AuthContext";
import toast from "react-hot-toast";

const OrderHistory = () => {
  const { user } = useAuth();
  const [restaurantId, setRestaurantId] = useState(null);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("ALL");

  useEffect(() => {
    const fetchRestaurantId = async () => {
      if (!user?.uid) return;

      try {
        const restaurantRef = collection(db, "restaurants");
        const q = query(restaurantRef, where("uid", "==", user.uid));
        const snapshot = await getDocs(q);

        if (!snapshot.empty) {
          const doc = snapshot.docs[0];
          setRestaurantId(doc.id);
        } else {
          toast.error("No restaurant found for user.");
        }
      } catch (err) {
        console.error("Error fetching restaurant ID:", err);
        toast.error("Failed to fetch restaurant info.");
      }
    };

    fetchRestaurantId();
  }, [user]);

  useEffect(() => {
    const fetchOrders = async () => {
      if (!restaurantId) return;

      try {
        const ordersRef = collection(db, "orders");
        const q = query(
          ordersRef,
          where("restaurantId", "==", restaurantId),
          where("status", "in", ["DELIVERED", "DECLINED", "COMPLETE"]),
          orderBy("createdAt", "desc")
        );
        const snapshot = await getDocs(q);

        const data = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));

        setOrders(data);
      } catch (err) {
        console.error("Failed to fetch order history:", err);
        toast.error("Could not load order history.");
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, [restaurantId]);

  // ✅ Filter by date range
  const now = new Date();
  const filteredOrders = orders.filter((order) => {
    if (!order.createdAt?.toDate) return false;
    const date = order.createdAt.toDate();

    if (filter === "LAST_7_DAYS") {
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(now.getDate() - 7);
      return date >= sevenDaysAgo;
    }

    if (filter === "THIS_MONTH") {
      return (
        date.getMonth() === now.getMonth() &&
        date.getFullYear() === now.getFullYear()
      );
    }

    return true; // "ALL"
  });

  // ✅ Stats
  const completedOrders = filteredOrders.filter(
    (order) => order.status === "DELIVERED" || order.status === "COMPLETE"
  );
  const cancelledOrders = filteredOrders.filter(
    (order) => order.status === "DECLINED"
  );

  const completedRevenue = completedOrders.reduce(
    (sum, order) => sum + (order.total || 0),
    0
  );
  const cancelledRevenue = cancelledOrders.reduce(
    (sum, order) => sum + (order.total || 0),
    0
  );

  return (
    <div className="p-4">
      {/* Header + Stats */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 gap-4">
        <div>
          <h1 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
            Order History
          </h1>

          {/* Filter Selector */}
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="border dark:border-gray-600 dark:bg-gray-800 dark:text-white px-3 py-2 rounded"
          >
            <option value="ALL">All Time</option>
            <option value="LAST_7_DAYS">Last 7 Days</option>
            <option value="THIS_MONTH">This Month</option>
          </select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full md:w-auto">
          <div className="bg-green-100 dark:bg-green-900 text-green-900 dark:text-green-100 px-4 py-3 rounded shadow">
            <p className="text-sm">✅ Completed Orders</p>
            <p className="text-lg font-bold">{completedOrders.length}</p>
            <p className="text-sm">{completedRevenue.toFixed(2)} DA</p>
          </div>
          <div className="bg-red-100 dark:bg-red-900 text-red-900 dark:text-red-100 px-4 py-3 rounded shadow">
            <p className="text-sm">❌ Cancelled Revenue</p>
            <p className="text-lg font-bold">{cancelledRevenue.toFixed(2)} DA</p>
          </div>
        </div>
      </div>

      {/* Orders List */}
      {loading ? (
        <p className="text-gray-600 dark:text-gray-300">Loading orders...</p>
      ) : filteredOrders.length === 0 ? (
        <p className="text-gray-600 dark:text-gray-300">
          No orders found for this filter.
        </p>
      ) : (
        <ul className="space-y-4">
          {filteredOrders.map((order) => (
            <li
              key={order.id}
              className="border p-4 rounded shadow bg-white dark:bg-gray-800 text-gray-800 dark:text-white"
            >
              <p>
                <strong>Customer:</strong>{" "}
                {`${order.userFirstName ?? ""} ${order.userLastName ?? ""}`.trim() || "N/A"}
              </p>
              <p>
                <strong>Total:</strong>{" "}
                {order.total ? `${order.total} DA` : "N/A"}
              </p>
              <p>
                <strong>Status:</strong> {order.status}
              </p>
              {order.createdAt?.toDate && (
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {order.createdAt.toDate().toLocaleString()}
                </p>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default OrderHistory;
