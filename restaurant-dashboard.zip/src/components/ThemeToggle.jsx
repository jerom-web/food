import { useContext } from "react"; 
import { ThemeContext } from "../context/ThemeContext";
import { useAuth } from "@/context/AuthContext";

const ThemeToggle = () => {
  const { theme, toggleTheme } = useContext(ThemeContext);

  return (
    <div className="w-full flex justify-end px-4 pt-4">
      <button
        onClick={toggleTheme}
        className="p-2 rounded-full bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white hover:scale-105 transition"
        title="Toggle Theme"
      >
        {theme === "light" ? "☾" : "☀︎"}
      </button>
    </div>
  );
};

export default ThemeToggle;

