import { useEffect } from "react";
import { useRouter } from "next/router";

export default function Register() {
  const router = useRouter();

  useEffect(() => {
    router.replace("/login"); // or wherever you want to redirect
  }, []);

  return null;
}
