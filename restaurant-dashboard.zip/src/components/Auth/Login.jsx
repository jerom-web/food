import { useState } from "react";
import { useRouter } from "next/router";
import { auth, db } from "@/firebase/firebase";
import { signInWithEmailAndPassword } from "firebase/auth";
import { doc, updateDoc } from "firebase/firestore";
import toast from "react-hot-toast";
import Link from 'next/link';

const Login = () => {
  const [form, setForm] = useState({ email: "", password: "" });
  const router = useRouter();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      // Sign in first
      const { user } = await signInWithEmailAndPassword(auth, form.email, form.password);
      toast.success("Login successful");

      // Get and save user location
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const latitude = position.coords.latitude;
          const longitude = position.coords.longitude;

          try {
            await updateDoc(doc(db, "restaurants", user.uid), {
              restaurantLatitude: latitude,
              restaurantLongitude: longitude,
              lastLoginAt: new Date(),
            });
          } catch (err) {
            console.warn("Could not update GPS info:", err.message);
          }

          router.push("/");
        },
        (err) => {
          console.warn("Location permission denied:", err.message);
          router.push("/");
        }
      );
    } catch (error) {
      console.error("Login failed:", error.message);
      if (error.code === "auth/invalid-credential" || error.code === "auth/user-not-found") {
        toast.error("Invalid email or password");
      } else {
        toast.error("Something went wrong. Try again.");
      }
    }
  };

  return (
    <form
      onSubmit={handleLogin}
      className="max-w-md mx-auto mt-10 p-6 bg-white dark:bg-gray-900 rounded-xl shadow-md space-y-4"
    >
      <h2 className="text-2xl font-bold text-center text-gray-800 dark:text-white">Login</h2>

      <input
        name="email"
        type="email"
        value={form.email}
        onChange={(e) => setForm({ ...form, email: e.target.value })}
        placeholder="Email"
        className="w-full p-3 border rounded dark:bg-gray-800 dark:text-white"
      />

      <input
        name="password"
        type="password"
        value={form.password}
        onChange={(e) => setForm({ ...form, password: e.target.value })}
        placeholder="Password"
        className="w-full p-3 border rounded dark:bg-gray-800 dark:text-white"
      />

      <button className="w-full bg-green-600 text-white py-3 rounded hover:bg-green-700">
        Login
      </button>

      <p className="text-sm text-center text-gray-600 dark:text-gray-300">
        Don’t have an account?{" "}
        <Link  href="/register/" className="text-green-500 hover:text-green-700">Register</Link>
      </p>
    </form>
  );
};

export default Login;
