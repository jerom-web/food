module.exports = {
  i18n: {
    defaultLocale: 'en',
    locales: [ 'en','fr', 'ar'],
    localeDetection: true,
  },
  react: { useSuspense: true },
};